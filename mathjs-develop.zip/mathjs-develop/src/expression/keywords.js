// Reserved keywords not allowed to use in the parser
export const keywords = new Set([
  'end'
])
