# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [9.0.7](https://github.com/serialport/node-serialport/compare/v9.0.6...v9.0.7) (2021-02-22)

**Note:** Version bump only for package @serialport/parser-spacepacket





## [9.0.5](https://github.com/serialport/node-serialport/compare/v9.0.4...v9.0.5) (2020-12-20)

**Note:** Version bump only for package @serialport/parser-spacepacket
