'use strict';

module.exports = {
  bail: true,
  require: ['./test/initializers'],
  'spec': ['packages/**/*.test.js'],
}
