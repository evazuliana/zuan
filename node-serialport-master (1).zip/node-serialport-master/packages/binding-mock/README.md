# @serialport/BindingMock

This stream does some neat stuff.

This is why you'd use it.

This is how you use it.
```js
const bindingMock = new BindingMock()

```
