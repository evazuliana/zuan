// TODO: deprecated since v8, remove this deprecation warning in v9
throw new Error('The file "mathjs/main/es5/number.js" has been moved since mathjs@8.0.0. ' +
  'Please load "mathjs/number" or "mathjs/lib/cjs/number.js" instead.')
